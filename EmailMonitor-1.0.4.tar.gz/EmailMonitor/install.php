<?php
// ****** INSTALADOR DE MONITOR DE CONEXION DE EXTENSIONES PARA PBX BY AJTEL *******
// Copyright (C) 1995-2025  AJTEL Comunicaciones    <info@ajtel.net>
// Copyright (C) 1995-2025  Andre Vivar Balderrama Bustamante <andrevivar@ajtel.net>
// Desarrollado por AJTEL Comunicaciones y Andre Vivar Balderrama Bustamante

// install.php
if (!defined('FREEPBX_IS_AUTH')) { die('No direct script access allowed'); }

// Crear o actualizar la tabla emailmonitor_settings
$sql = "CREATE TABLE IF NOT EXISTS emailmonitor_settings (
    setting_key VARCHAR(50) NOT NULL,
    setting_value TEXT NOT NULL,
    PRIMARY KEY (setting_key)
)";
$db->query($sql);

// Limpiar los datos existentes en la tabla para empezar desde cero
$db->query("DELETE FROM emailmonitor_settings");

// Asegurarse de que los nuevos campos est�n disponibles (usaremos claves separadas en la misma tabla)
$check_keys = ['group_names', 'group_emails', 'group_extensions', 'extension_emails', 'extension_names', 'notification_intervals', 'disable_notifications', 'daily_message_limits'];
foreach ($check_keys as $key) {
    $exists = $db->getOne("SELECT setting_value FROM emailmonitor_settings WHERE setting_key = ?", [$key]);
    if (!$exists) {
        if ($key === 'group_names') {
            $db->query("INSERT INTO emailmonitor_settings (setting_key, setting_value) VALUES (?, ?)", [$key, json_encode(['Grupo 1', 'Grupo 2', 'Grupo 3', 'Grupo 4', 'Grupo 5'])]);
        } else {
            $db->query("INSERT INTO emailmonitor_settings (setting_key, setting_value) VALUES (?, ?)", [$key, json_encode([])]);
        }
    }
}

// Copiar el script monitor_extension.sh a /usr/local/bin/
$script_source = __DIR__ . '/scripts/monitor_extension.sh';
$script_temp = '/tmp/monitor_extension.sh';
$script_dest = '/usr/local/bin/monitor_extension.sh';

// Verificar si el archivo fuente existe
if (!file_exists($script_source)) {
    die("Error: Source file $script_source does not exist.\n");
}

// Copiar el archivo a /tmp/ primero
if (!copy($script_source, $script_temp)) {
    die("Error: Failed to copy $script_source to $script_temp. Check permissions on /tmp/.\n");
}

// Verificar si el directorio destino existe, y crearlo si no existe
$dest_dir = dirname($script_dest);
if (!is_dir($dest_dir)) {
    mkdir($dest_dir, 0755, true);
    exec("sudo chown root:root $dest_dir", $output, $return_code);
    if ($return_code !== 0) {
        die("Error: Failed to change owner of $dest_dir to root:root. Ensure the asterisk user has sudo privileges for 'chown'.\n");
    }
}

// Verificar si el archivo destino ya existe y eliminarlo si es posible
if (file_exists($script_dest)) {
    exec("sudo rm $script_dest", $output, $return_code);
    if ($return_code !== 0) {
        die("Error: Failed to remove existing $script_dest. Ensure the asterisk user has sudo privileges for 'rm'.\n");
    }
}

// Verificar si el directorio destino es escribible, y ajustarlo si es necesario
if (!is_writable($dest_dir)) {
    exec("sudo chmod 777 $dest_dir", $output, $return_code);
    if ($return_code !== 0) {
        die("Error: Failed to set permissions to 777 on $dest_dir. Ensure the asterisk user has sudo privileges for 'chmod'.\n");
    }
}

// Mover el archivo desde /tmp/ al destino final
exec("sudo mv $script_temp $script_dest", $output, $return_code);
if ($return_code !== 0) {
    die("Error: Failed to move $script_temp to $script_dest. Ensure the asterisk user has sudo privileges for 'mv'.\n");
}

// Restaurar permisos del directorio destino
exec("sudo chmod 755 $dest_dir", $output, $return_code);
if ($return_code !== 0) {
    die("Error: Failed to restore permissions on $dest_dir to 755. Ensure the asterisk user has sudo privileges for 'chmod'.\n");
}

// Ajustar permisos del script
exec("sudo chown asterisk:asterisk $script_dest", $output, $return_code);
if ($return_code !== 0) {
    die("Error: Failed to change owner of $script_dest to asterisk:asterisk. Ensure the asterisk user has sudo privileges for 'chown'.\n");
}
exec("sudo chmod 755 $script_dest", $output, $return_code);
if ($return_code !== 0) {
    die("Error: Failed to set permissions on $script_dest to 755. Ensure the asterisk user has sudo privileges for 'chmod'.\n");
}

// Copiar el script reset_message_count.sh a /usr/local/bin/
$reset_script_source = __DIR__ . '/scripts/reset_message_count.sh';
$reset_script_temp = '/tmp/reset_message_count.sh';
$reset_script_dest = '/usr/local/bin/reset_message_count.sh';

// Verificar si el archivo fuente existe
if (!file_exists($reset_script_source)) {
    die("Error: Source file $reset_script_source does not exist.\n");
}

// Copiar el archivo a /tmp/ primero
if (!copy($reset_script_source, $reset_script_temp)) {
    die("Error: Failed to copy $reset_script_source to $reset_script_temp. Check permissions on /tmp/.\n");
}

// Verificar si el archivo destino ya existe y eliminarlo si es posible
if (file_exists($reset_script_dest)) {
    exec("sudo rm $reset_script_dest", $output, $return_code);
    if ($return_code !== 0) {
        die("Error: Failed to remove existing $reset_script_dest. Ensure the asterisk user has sudo privileges for 'rm'.\n");
    }
}

// Verificar si el directorio destino es escribible, y ajustarlo si es necesario
if (!is_writable($dest_dir)) {
    exec("sudo chmod 777 $dest_dir", $output, $return_code);
    if ($return_code !== 0) {
        die("Error: Failed to set permissions to 777 on $dest_dir. Ensure the asterisk user has sudo privileges for 'chmod'.\n");
    }
}

// Mover el archivo desde /tmp/ al destino final
exec("sudo mv $reset_script_temp $reset_script_dest", $output, $return_code);
if ($return_code !== 0) {
    die("Error: Failed to move $reset_script_temp to $reset_script_dest. Ensure the asterisk user has sudo privileges for 'mv'.\n");
}

// Restaurar permisos del directorio destino
exec("sudo chmod 755 $dest_dir", $output, $return_code);
if ($return_code !== 0) {
    die("Error: Failed to restore permissions on $dest_dir to 755. Ensure the asterisk user has sudo privileges for 'chmod'.\n");
}

// Ajustar permisos del script
exec("sudo chown asterisk:asterisk $reset_script_dest", $output, $return_code);
if ($return_code !== 0) {
    die("Error: Failed to change owner of $reset_script_dest to asterisk:asterisk. Ensure the asterisk user has sudo privileges for 'chown'.\n");
}
exec("sudo chmod 755 $reset_script_dest", $output, $return_code);
if ($return_code !== 0) {
    die("Error: Failed to set permissions on $reset_script_dest to 755. Ensure the asterisk user has sudo privileges for 'chmod'.\n");
}

// Crear el archivo de servicio systemd en un directorio temporal
$temp_service_file = '/tmp/monitor_extension.service';
$service_file = '/etc/systemd/system/monitor_extension.service';
$service_content = <<<EOD
[Unit]
Description=Monitor de conexi�n de extensiones para PBX AJTEL
After=network.target

[Service]
ExecStart=/usr/local/bin/monitor_extension.sh
Restart=always
User=asterisk
Group=asterisk

[Install]
WantedBy=multi-user.target
EOD;

// Escribir el archivo en /tmp/ asegur�ndonos de que sea UTF-8
file_put_contents($temp_service_file, mb_convert_encoding($service_content, 'UTF-8', 'auto'));

// Verificar si el archivo destino ya existe y eliminarlo si es posible
if (file_exists($service_file)) {
    exec("sudo rm $service_file", $output, $return_code);
    if ($return_code !== 0) {
        die("Error: Failed to remove existing $service_file. Ensure the asterisk user has sudo privileges for 'rm'.\n");
    }
}

// Verificar si el directorio destino es escribible, y ajustarlo si es necesario
$systemd_dir = dirname($service_file);
if (!is_writable($systemd_dir)) {
    exec("sudo chmod 777 $systemd_dir", $output, $return_code);
    if ($return_code !== 0) {
        die("Error: Failed to set permissions to 777 on $systemd_dir. Ensure the asterisk user has sudo privileges for 'chmod'.\n");
    }
}

// Mover el archivo a /etc/systemd/system/ y ajustar permisos
exec("sudo mv $temp_service_file $service_file", $output, $return_code);
if ($return_code !== 0) {
    die("Error: Failed to move $temp_service_file to $service_file. Ensure the asterisk user has sudo privileges for 'mv'.\n");
}

exec("sudo chmod 644 $service_file", $output, $return_code);
if ($return_code !== 0) {
    die("Error: Failed to set permissions on $service_file to 644. Ensure the asterisk user has sudo privileges for 'chmod'.\n");
}

// Restaurar permisos de /etc/systemd/system/
exec("sudo chmod 755 $systemd_dir", $output, $return_code);
if ($return_code !== 0) {
    die("Error: Failed to restore permissions on $systemd_dir to 755. Ensure the asterisk user has sudo privileges for 'chmod'.\n");
}

// Recargar systemd y habilitar/iniciar el servicio
exec('sudo systemctl daemon-reload', $output, $return_code);
if ($return_code !== 0) {
    die("Error: Failed to reload systemd daemon. Ensure the asterisk user has sudo privileges for 'systemctl'.\n");
}
exec('sudo systemctl enable monitor_extension.service', $output, $return_code);
if ($return_code !== 0) {
    die("Error: Failed to enable monitor_extension.service. Ensure the asterisk user has sudo privileges for 'systemctl'.\n");
}
exec('sudo systemctl start monitor_extension.service', $output, $return_code);
if ($return_code !== 0) {
    echo "Warning: Failed to start monitor_extension.service. Return code: $return_code. Output: " . implode("\n", $output) . "\n";
    echo "Please check the service status manually with 'systemctl status monitor_extension.service' and review logs in /var/log/monitor_extension_error.log.\n";
} else {
    // Verificar que el servicio se inici� correctamente
    $service_status = exec('systemctl is-active monitor_extension.service');
    if ($service_status !== 'active') {
        echo "Warning: monitor_extension.service is not active. Current status: $service_status.\n";
        echo "Please check the service status manually with 'systemctl status monitor_extension.service' and review logs in /var/log/monitor_extension_error.log.\n";
    } else {
        echo "EmailMonitor instalado correctamente.\n";
    }
}