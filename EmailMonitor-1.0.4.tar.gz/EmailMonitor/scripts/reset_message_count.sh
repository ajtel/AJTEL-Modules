#!/bin/bash
# ****** MONITOR DE CONEXION DE EXTENSIONES PARA PBX AJTEL *******
# Copyright (C) 1995-2025  AJTEL Comunicaciones    <info@ajtel.net>
# Copyright (C) 1995-2025  Andre Vivar Balderrama Bustamante <andrevivar@ajtel.net>
# Desarrollado por AJTEL Comunicaciones y Andre Vivar Balderrama Bustamante
# ****** SCRIPT PARA REINICIAR CONTEO DE MENSAJES DIARIOS *******

MESSAGE_COUNT_FILE="/tmp/extension_message_count.txt"

if [ $# -ne 1 ]; then
    echo "Uso: $0 <extension>"
    exit 1
fi

extension="$1"
current_date=$(date +%Y-%m-%d)

# Reiniciar el conteo de mensajes para la extensi�n
grep -v "^$current_date $extension " "$MESSAGE_COUNT_FILE" > /tmp/message_count_tmp.txt
mv /tmp/message_count_tmp.txt "$MESSAGE_COUNT_FILE"

echo "Conteo de mensajes diarios reiniciado para la extensi�n $extension"