<?php
// ****** INSTALADOR DE MONITOR DE CONEXION DE EXTENSIONES PARA PBX BY AJTEL *******
// Copyright (C) 1995-2025  AJTEL Comunicaciones    <info@ajtel.net>
// Copyright (C) 1995-2025  Andre Vivar Balderrama Bustamante <andrevivar@ajtel.net>
// Desarrollado por AJTEL Comunicaciones y Andre Vivar Balderrama Bustamante

// Emailmonitor.class.php
$bootstrap_settings['freepbx_auth'] = false;
include_once '/var/www/html/admin/bootstrap.php';

class Emailmonitor extends FreePBX_Helpers implements BMO {
    public function __construct($freepbx = null) {
        if ($freepbx == null) {
            throw new Exception("Need to be instantiated with a FreePBX object");
        }
        $this->FreePBX = $freepbx;
        $this->db = $freepbx->Database;
    }

    public function install() {}
    public function uninstall() {}
    public function backup() {}
    public function restore($backup) {}

    // Parse extension ranges (e.g., "4101-4125") into a list of extensions
    private function parseExtensionRange($range) {
        $extensions = [];
        if (preg_match('/^(\d+)-(\d+)$/', $range, $matches)) {
            $start = (int)$matches[1];
            $end = (int)$matches[2];
            if ($start <= $end) {
                for ($i = $start; $i <= $end; $i++) {
                    $extensions[] = (string)$i;
                }
            }
        } else {
            // If not a range, assume it's a single extension or comma-separated list
            $extensions = array_map('trim', explode(',', $range));
        }
        return $extensions;
    }

    // Validate email addresses
    private function validateEmail($email) {
        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    }

    public function doConfigPageInit($page) {
        if ($page == "emailmonitor") {
            if (isset($_REQUEST['action'])) {
                switch ($_REQUEST['action']) {
                    case 'save':
                        $group_names = isset($_REQUEST['group_names']) ? $_REQUEST['group_names'] : [];
                        $group_emails = isset($_REQUEST['group_emails']) ? $_REQUEST['group_emails'] : [];
                        $group_extensions = isset($_REQUEST['group_extensions']) ? $_REQUEST['group_extensions'] : [];
                        $extension_emails = isset($_REQUEST['extension_emails']) ? $_REQUEST['extension_emails'] : [];
                        $extension_names = isset($_REQUEST['extension_names']) ? $_REQUEST['extension_names'] : [];
                        $notification_intervals = isset($_REQUEST['notification_intervals']) ? $_REQUEST['notification_intervals'] : [];
                        $disable_notifications = isset($_REQUEST['disable_notifications']) ? $_REQUEST['disable_notifications'] : [];
                        $daily_message_limits = isset($_REQUEST['daily_message_limits']) ? $_REQUEST['daily_message_limits'] : [];

                        // Parse extension ranges for groups
                        foreach ($group_extensions as $group_id => $ext_list) {
                            $expanded_extensions = [];
                            $ranges = array_map('trim', explode(',', $ext_list));
                            foreach ($ranges as $range) {
                                if (!empty($range)) {
                                    $expanded_extensions = array_merge($expanded_extensions, $this->parseExtensionRange($range));
                                }
                            }
                            $group_extensions[$group_id] = implode(',', $expanded_extensions);
                        }

                        // Validate group emails
                        foreach ($group_emails as $group_id => $email_list) {
                            $emails = array_map('trim', explode(',', $email_list));
                            $valid_emails = [];
                            foreach ($emails as $email) {
                                if (!empty($email) && $this->validateEmail($email)) {
                                    $valid_emails[] = $email;
                                } else if (!empty($email)) {
                                    error_log("Invalid email in group $group_id: $email");
                                }
                            }
                            $group_emails[$group_id] = implode(',', $valid_emails);
                        }

                        // Validate extension emails
                        foreach ($extension_emails as $ext_id => $email) {
                            if (!empty($email) && !$this->validateEmail($email)) {
                                error_log("Invalid email for extension $ext_id: $email");
                                $extension_emails[$ext_id] = '';
                            }
                        }

                        // Enforce minimum daily message limit of 10
                        foreach ($daily_message_limits as $ext_id => $limit) {
                            $limit = (int)$limit;
                            if ($limit > 0 && $limit < 10) {
                                $daily_message_limits[$ext_id] = 10;
                            }
                        }

                        // Log para depurar los datos recibidos
                        error_log("Saving group_names: " . print_r($group_names, true));
                        error_log("Saving group_emails: " . print_r($group_emails, true));
                        error_log("Saving group_extensions: " . print_r($group_extensions, true));
                        error_log("Saving extension_emails: " . print_r($extension_emails, true));
                        error_log("Saving extension_names: " . print_r($extension_names, true));
                        error_log("Saving notification_intervals: " . print_r($notification_intervals, true));
                        error_log("Saving disable_notifications: " . print_r($disable_notifications, true));
                        error_log("Saving daily_message_limits: " . print_r($daily_message_limits, true));

                        // Serializar los datos a JSON antes de guardarlos
                        $group_names_json = json_encode($group_names);
                        $group_emails_json = json_encode($group_emails);
                        $group_extensions_json = json_encode($group_extensions);
                        $extension_emails_json = json_encode($extension_emails);
                        $extension_names_json = json_encode($extension_names);
                        $notification_intervals_json = json_encode($notification_intervals);
                        $disable_notifications_json = json_encode($disable_notifications);
                        $daily_message_limits_json = json_encode($daily_message_limits);

                        // Guardar los datos en la base de datos usando prepared statements
                        $stmt = $this->db->prepare("INSERT INTO emailmonitor_settings (setting_key, setting_value) VALUES ('group_names', :value) ON DUPLICATE KEY UPDATE setting_value = :value");
                        $stmt->execute(['value' => $group_names_json]);
                        $stmt = $this->db->prepare("INSERT INTO emailmonitor_settings (setting_key, setting_value) VALUES ('group_emails', :value) ON DUPLICATE KEY UPDATE setting_value = :value");
                        $stmt->execute(['value' => $group_emails_json]);
                        $stmt = $this->db->prepare("INSERT INTO emailmonitor_settings (setting_key, setting_value) VALUES ('group_extensions', :value) ON DUPLICATE KEY UPDATE setting_value = :value");
                        $stmt->execute(['value' => $group_extensions_json]);
                        $stmt = $this->db->prepare("INSERT INTO emailmonitor_settings (setting_key, setting_value) VALUES ('extension_emails', :value) ON DUPLICATE KEY UPDATE setting_value = :value");
                        $stmt->execute(['value' => $extension_emails_json]);
                        $stmt = $this->db->prepare("INSERT INTO emailmonitor_settings (setting_key, setting_value) VALUES ('extension_names', :value) ON DUPLICATE KEY UPDATE setting_value = :value");
                        $stmt->execute(['value' => $extension_names_json]);
                        $stmt = $this->db->prepare("INSERT INTO emailmonitor_settings (setting_key, setting_value) VALUES ('notification_intervals', :value) ON DUPLICATE KEY UPDATE setting_value = :value");
                        $stmt->execute(['value' => $notification_intervals_json]);
                        $stmt = $this->db->prepare("INSERT INTO emailmonitor_settings (setting_key, setting_value) VALUES ('disable_notifications', :value) ON DUPLICATE KEY UPDATE setting_value = :value");
                        $stmt->execute(['value' => $disable_notifications_json]);
                        $stmt = $this->db->prepare("INSERT INTO emailmonitor_settings (setting_key, setting_value) VALUES ('daily_message_limits', :value) ON DUPLICATE KEY UPDATE setting_value = :value");
                        $stmt->execute(['value' => $daily_message_limits_json]);

                        // Eliminar la clave antigua 'daily_message_limit' si existe
                        $this->db->query("DELETE FROM emailmonitor_settings WHERE setting_key = 'daily_message_limit'");

                        // Leer los datos guardados para confirmar
                        $group_names_saved = $this->db->getOne("SELECT setting_value FROM emailmonitor_settings WHERE setting_key = 'group_names'");
                        $group_emails_saved = $this->db->getOne("SELECT setting_value FROM emailmonitor_settings WHERE setting_key = 'group_emails'");
                        $group_extensions_saved = $this->db->getOne("SELECT setting_value FROM emailmonitor_settings WHERE setting_key = 'group_extensions'");
                        $extension_emails_saved = $this->db->getOne("SELECT setting_value FROM emailmonitor_settings WHERE setting_key = 'extension_emails'");
                        $extension_names_saved = $this->db->getOne("SELECT setting_value FROM emailmonitor_settings WHERE setting_key = 'extension_names'");
                        $notification_intervals_saved = $this->db->getOne("SELECT setting_value FROM emailmonitor_settings WHERE setting_key = 'notification_intervals'");
                        $disable_notifications_saved = $this->db->getOne("SELECT setting_value FROM emailmonitor_settings WHERE setting_key = 'disable_notifications'");
                        $daily_message_limits_saved = $this->db->getOne("SELECT setting_value FROM emailmonitor_settings WHERE setting_key = 'daily_message_limits'");

                        error_log("After saving group_names: " . $group_names_saved);
                        error_log("After saving group_emails: " . $group_emails_saved);
                        error_log("After saving group_extensions: " . $group_extensions_saved);
                        error_log("After saving extension_emails: " . $extension_emails_saved);
                        error_log("After saving extension_names: " . $extension_names_saved);
                        error_log("After saving notification_intervals: " . $notification_intervals_saved);
                        error_log("After saving disable_notifications: " . $disable_notifications_saved);
                        error_log("After saving daily_message_limits: " . $daily_message_limits_saved);
                        break;
                    case 'reset_message_count':
                        $extension = isset($_REQUEST['extension']) ? $_REQUEST['extension'] : '';
                        if (!empty($extension)) {
                            $command = "/usr/local/bin/reset_message_count.sh $extension";
                            exec($command, $output, $return_code);
                            if ($return_code === 0) {
                                error_log("Conteo de mensajes reiniciado para la extensi�n $extension: " . implode("\n", $output));
                            } else {
                                error_log("Error al reiniciar el conteo de mensajes para la extensi�n $extension: " . implode("\n", $output));
                            }
                        }
                        break;
                }
            }
        }
    }

    public function getActionBar($request) {
        if ($request['display'] == 'emailmonitor') {
            return [
                'save' => [
                    'name' => 'Save',
                    'id' => 'save',
                    'value' => 'Save'
                ]
            ];
        }
        return [];
    }

    public function showPage() {
        // Leer los datos y deserializarlos desde la base de datos
        $group_names_json = $this->db->getOne("SELECT setting_value FROM emailmonitor_settings WHERE setting_key = 'group_names'");
        $group_emails_json = $this->db->getOne("SELECT setting_value FROM emailmonitor_settings WHERE setting_key = 'group_emails'");
        $group_extensions_json = $this->db->getOne("SELECT setting_value FROM emailmonitor_settings WHERE setting_key = 'group_extensions'");
        $extension_emails_json = $this->db->getOne("SELECT setting_value FROM emailmonitor_settings WHERE setting_key = 'extension_emails'");
        $extension_names_json = $this->db->getOne("SELECT setting_value FROM emailmonitor_settings WHERE setting_key = 'extension_names'");
        $notification_intervals_json = $this->db->getOne("SELECT setting_value FROM emailmonitor_settings WHERE setting_key = 'notification_intervals'");
        $disable_notifications_json = $this->db->getOne("SELECT setting_value FROM emailmonitor_settings WHERE setting_key = 'disable_notifications'");
        $daily_message_limits_json = $this->db->getOne("SELECT setting_value FROM emailmonitor_settings WHERE setting_key = 'daily_message_limits'");
        $group_names = $group_names_json ? json_decode($group_names_json, true) : ['Grupo 1', 'Grupo 2', 'Grupo 3', 'Grupo 4', 'Grupo 5'];
        $group_emails = $group_emails_json ? json_decode($group_emails_json, true) : [];
        $group_extensions = $group_extensions_json ? json_decode($group_extensions_json, true) : [];
        $extension_emails = $extension_emails_json ? json_decode($extension_emails_json, true) : [];
        $extension_names = $extension_names_json ? json_decode($extension_names_json, true) : [];
        $notification_intervals = $notification_intervals_json ? json_decode($notification_intervals_json, true) : [];
        $disable_notifications = $disable_notifications_json ? json_decode($disable_notifications_json, true) : [];
        $daily_message_limits = $daily_message_limits_json ? json_decode($daily_message_limits_json, true) : [];

        // Crear el HTML con el logo en el lado derecho
        $html = '<div class="container-fluid">';
        $html .= '<div class="row">';
        
        // Contenido principal (formularios) a la izquierda
        $html .= '<div class="col-md-8">';
        $html .= '<h2>AJTEL Email Monitor Configuration</h2>';
        $html .= '<form id="emailmonitor_form" method="post" action="?display=emailmonitor">';
        $html .= '<input type="hidden" name="action" value="save">';

        // Group Email Configuration
        $html .= '<h3>Group Emails</h3>';
        $html .= '<table class="table table-striped">';
        $html .= '<tr><th>Group Name (Editable)</th><th>Extensions (comma-separated, e.g., 101,102 or ranges like 4101-4125)</th><th>Email Addresses (comma-separated)</th></tr>';
        $group_ids = ['group1', 'group2', 'group3', 'group4', 'group5'];
        foreach ($group_ids as $index => $group_id) {
            $group_name = isset($group_names[$index]) ? $group_names[$index] : "Grupo " . ($index + 1);
            $emails = isset($group_emails[$group_id]) ? $group_emails[$group_id] : '';
            $extensions = isset($group_extensions[$group_id]) ? $group_extensions[$group_id] : '';
            $html .= "<tr>";
            $html .= "<td><input type='text' name='group_names[$index]' value='$group_name' class='form-control' title='Nombre del grupo para identificar a qui�n se enviar�n las notificaciones'></td>";
            $html .= "<td><input type='text' name='group_extensions[$group_id]' value='$extensions' class='form-control' placeholder='e.g., 101,102 or 4101-4125' title='Extensiones que pertenecen a este grupo (separadas por comas o rangos como 4101-4125)'></td>";
            $html .= "<td><input type='text' name='group_emails[$group_id]' value='$emails' class='form-control' placeholder='e.g., user1@example.com,user2@example.com' title='Correos electr�nicos que recibir�n notificaciones para este grupo (separados por comas)'></td>";
            $html .= "</tr>";
        }
        $html .= '</table>';

        // Extension Email and Name Configuration
        $html .= '<h3>Extension Emails and Names</h3>';
        $html .= '<table class="table table-striped">';
        $html .= '<tr>';
        $html .= '<th>Extension</th>';
        $html .= '<th>Original Name</th>';
        $html .= '<th>Custom Name (Editable)</th>';
        $html .= '<th>Email Address</th>';
        $html .= '<th>Notification Interval (minutes)</th>';
        $html .= '<th>Daily Message Limit (0 for unlimited, minimum 10 recommended for 4 disconnect/reconnect events)</th>';
        $html .= '<th>Emails Sent Today</th>';
        $html .= '<th>Disable Notifications <br><input type="checkbox" id="select-all-disable" onclick="toggleDisableAll(this)" title="Marcar para deshabilitar notificaciones en todas las extensiones"></th>';
        $html .= '<th>Reset Message Count</th>';
        $html .= '</tr>';
        $extensions = $this->FreePBX->Core->getAllUsers();
        foreach ($extensions as $ext) {
            $ext_id = $ext['extension'];
            $original_name = $ext['name'] ?: 'Usuario';
            $custom_name = isset($extension_names[$ext_id]) ? $extension_names[$ext_id] : $original_name;
            $email = isset($extension_emails[$ext_id]) ? $extension_emails[$ext_id] : $ext['email'];
            $interval = isset($notification_intervals[$ext_id]) ? (int)$notification_intervals[$ext_id] : 1; // Default to 1 minute
            $message_limit = isset($daily_message_limits[$ext_id]) ? (int)$daily_message_limits[$ext_id] : 10; // Default to 10
            $disabled = isset($disable_notifications[$ext_id]) && $disable_notifications[$ext_id] ? 'checked' : '';
            // Get the current message count for today
            $current_date = date('Y-m-d');
            $message_count = shell_exec("grep '^$current_date $ext_id ' /tmp/extension_message_count.txt | awk '{print \$3}' || echo '0'");
            $message_count = trim($message_count);
            $html .= "<tr>";
            $html .= "<td>$ext_id</td>";
            $html .= "<td>$original_name</td>";
            $html .= "<td><input type='text' name='extension_names[$ext_id]' value='$custom_name' class='form-control' title='Nombre personalizado para esta extensi�n'></td>";
            $html .= "<td><input type='text' name='extension_emails[$ext_id]' value='$email' class='form-control' title='Correo electr�nico adicional para esta extensi�n (debe incluir @ y un dominio v�lido)'></td>";
            $html .= "<td><input type='number' name='notification_intervals[$ext_id]' value='$interval' class='form-control' min='1' title='Intervalo en minutos entre notificaciones para esta extensi�n'></td>";
            $html .= "<td><input type='number' name='daily_message_limits[$ext_id]' value='$message_limit' class='form-control' min='10' title='L�mite de mensajes diarios (0 para ilimitado, m�nimo 10 recomendado para 4 eventos de desconexi�n/reconexi�n)'></td>";
            $html .= "<td>$message_count</td>";
            $html .= "<td><input type='checkbox' name='disable_notifications[$ext_id]' value='1' class='disable-checkbox' $disabled title='Deshabilitar notificaciones para esta extensi�n'></td>";
            $html .= "<td><a href='?display=emailmonitor&action=reset_message_count&extension=$ext_id' class='btn btn-warning btn-sm' title='Reiniciar el conteo de mensajes diarios para esta extensi�n'>Reset</a></td>";
            $html .= "</tr>";
        }
        $html .= '</table>';

        // JavaScript para manejar el "select all" de disable notifications
        $html .= '<script>
            function toggleDisableAll(checkbox) {
                var checkboxes = document.getElementsByClassName("disable-checkbox");
                for (var i = 0; i < checkboxes.length; i++) {
                    checkboxes[i].checked = checkbox.checked;
                }
            }
        </script>';

        $html .= '</form>';
        $html .= '</div>'; // Cierra col-md-8

        // Logo a la derecha usando una ruta absoluta
        $html .= '<div class="col-md-4">';
        $html .= '<div style="text-align: right; margin-top: 20px;">';
        $html .= '<img src="/admin/modules/EmailMonitor/images/logo.png" alt="Logo" style="max-width: 200px; height: auto;">';
        $html .= '</div>';
        $html .= '</div>'; // Cierra col-md-4

        $html .= '</div>'; // Cierra row
        $html .= '</div>'; // Cierra container-fluid

        return $html;
    }
}

// Register the class with FreePBX autoloader
FreePBX::create()->Emailmonitor;