#!/bin/bash
# ****** MONITOR DE CONEXION DE EXTENSIONES PARA PBX AJTEL *******
# Copyright (C) 1995-2025  AJTEL Comunicaciones    <info@ajtel.net>
# Copyright (C) 1995-2025  Andre Vivar Balderrama Bustamante <andrevivar@ajtel.net>
# Desarrollado por AJTEL Comunicaciones y Andre Vivar Balderrama Bustamante
# ****** SCRIPT PARA REINICIAR CONTEO DE MENSAJES DIARIOS *******

MESSAGE_COUNT_FILE="/tmp/extension_message_count.txt"
ERROR_LOG="/var/log/monitor_extension_error.log"

error_log() {
    local message="$1"
    printf "%s [ERROR]: %s\n" "$(date '+%Y-%m-%d %H:%M:%S')" "$message" >> "$ERROR_LOG"
}

if [ $# -ne 1 ]; then
    echo "Uso: $0 <extension>"
    error_log "Uso incorrecto: se requiere una extensi�n"
    exit 1
fi

extension="$1"
current_date=$(date +%Y-%m-%d)

# Reiniciar el conteo de mensajes para la extensi�n
grep -v "^$current_date $extension " "$MESSAGE_COUNT_FILE" > /tmp/message_count_tmp.txt
if [ $? -ne 0 ]; then
    error_log "Error al usar grep en $MESSAGE_COUNT_FILE para extensi�n $extension"
    echo "Error: Failed to grep $MESSAGE_COUNT_FILE"
    exit 1
fi

mv /tmp/message_count_tmp.txt "$MESSAGE_COUNT_FILE"
if [ $? -ne 0 ]; then
    error_log "Error al mover /tmp/message_count_tmp.txt a $MESSAGE_COUNT_FILE para extensi�n $extension"
    echo "Error: Failed to move /tmp/message_count_tmp.txt to $MESSAGE_COUNT_FILE"
    exit 1
fi

echo "Conteo de mensajes diarios reiniciado para la extensi�n $extension"