#!/bin/bash
# ****** MONITOR DE CONEXION DE EXTENSIONES PARA PBX AJTEL *******
# Copyright (C) 1995-2025  AJTEL Comunicaciones    <info@ajtel.net>
# Copyright (C) 1995-2025  Andre Vivar Balderrama Bustamante <andrevivar@ajtel.net>
# Desarrollado por AJTEL Comunicaciones y Andre Vivar Balderrama Bustamante

# Establecer codificaci�n UTF-8 para el script
export LC_ALL=es_MX.UTF-8
export LANG=es_MX.UTF-8

STATE_FILE="/tmp/extension_status.txt"
MESSAGE_COUNT_FILE="/tmp/extension_message_count.txt"
MYSQL_DB="asterisk"
LOG_FILE="/var/log/monitor_extension.log"
ERROR_LOG="/var/log/monitor_extension_error.log"
ASTERISK="/usr/sbin/asterisk"
MYSQL="/usr/bin/mysql"
SENDMAIL="/usr/sbin/sendmail"
LAGGED_WAIT_TIME=300  # Tiempo de espera en segundos (5 minutos) para confirmar si un "Lagged" se convierte en "UNKNOWN" o "OFFLINE"

# Verificar que el locale sea UTF-8
if ! locale | grep -q "UTF-8"; then
    echo "Error: System locale does not support UTF-8. Please set LC_ALL=es_MX.UTF-8." >> "$ERROR_LOG"
    exit 1
fi

# Leer las credenciales de MySQL desde la configuraci�n de FreePBX
FREEPBX_CONF="/etc/freepbx.conf"
if [ ! -f "$FREEPBX_CONF" ]; then
    echo "Error: freepbx.conf not found at $FREEPBX_CONF" >> "$ERROR_LOG"
    exit 1
fi

# Extraer las credenciales en formato PHP ($amp_conf["KEY"] = "VALUE";)
MYSQL_USER=$(grep '\$amp_conf\["AMPDBUSER"\]' "$FREEPBX_CONF" | grep -oP '(?<=")[^"]*(?=";)')
MYSQL_PASS=$(grep '\$amp_conf\["AMPDBPASS"\]' "$FREEPBX_CONF" | grep -oP '(?<=")[^"]*(?=";)')

if [ -z "$MYSQL_USER" ] || [ -z "$MYSQL_PASS" ]; then
    echo "Error: Could not read MySQL credentials from $FREEPBX_CONF" >> "$ERROR_LOG"
    exit 1
fi

log() {
    local level="$1"
    local message="$2"
    printf "%s [%s]: %s\n" "$(date '+%Y-%m-%d %H:%M:%S')" "$level" "$message" >> "$LOG_FILE"
}

error_log() {
    local message="$1"
    printf "%s [ERROR]: %s\n" "$(date '+%Y-%m-%d %H:%M:%S')" "$message" >> "$ERROR_LOG"
}

encode_subject() {
    subject="$1"
    echo "=?UTF-8?B?$(echo -n "$subject" | base64)?="
}

encode_from() {
    name="$1"
    email="$2"
    echo "=?UTF-8?B?$(echo -n "$name" | base64)?= <$email>"
}

get_user_info() {
    extension=$1
    log "INFO" "Obteniendo informaci�n para la extensi�n $extension"
    result=$($MYSQL -u$MYSQL_USER -p$MYSQL_PASS -D$MYSQL_DB -N -e "SELECT email, displayname, fname, lname FROM userman_users WHERE default_extension = '$extension'" 2>>"$ERROR_LOG")
    if [ $? -ne 0 ]; then
        error_log "Error al conectar a la base de datos para la extensi�n $extension"
        echo ""
        return 1
    fi
    email=$(echo "$result" | awk '{print $1}')
    displayname=$(echo "$result" | awk '{print $2}')
    fname=$(echo "$result" | awk '{print $3}')
    lname=$(echo "$result" | awk '{print $4}')
    
    log "DEBUG" "Resultado de la consulta: extensi�n=$extension, email=$email, displayname=$displayname, fname=$fname, lname=$lname"
    
    if [ -n "$email" ] && [ "$email" != "NULL" ]; then
        if [ -n "$displayname" ] && [ "$displayname" != "NULL" ]; then
            name="$displayname"
        elif [ -n "$fname" ] && [ "$fname" != "NULL" ]; then
            name="$fname $lname"
        else
            name="Usuario"
        fi
        log "INFO" "Informaci�n obtenida: extensi�n=$extension, email=$email, name=$name"
        echo "$email|$name"
    else
        error_log "Email no v�lido para la extensi�n $extension: $email"
        echo ""
    fi
}

# Obtener correos de grupo desde la base de datos
get_group_emails() {
    group=$1
    group_emails_json=$($MYSQL -u$MYSQL_USER -p$MYSQL_PASS -D$MYSQL_DB -N -e "SELECT setting_value FROM emailmonitor_settings WHERE setting_key = 'group_emails'" 2>>"$ERROR_LOG")
    if [ $? -ne 0 ]; then
        error_log "Error al obtener los correos del grupo $group desde la base de datos"
        echo ""
        return 1
    fi
    log "DEBUG" "JSON de group_emails obtenido: $group_emails_json"
    # Deserializar el JSON y obtener el valor para el grupo
    result=$(php -r "\$group_emails = json_decode('$group_emails_json', true); echo \$group_emails['$group'] ?? '';" 2>>"$ERROR_LOG")
    if [ $? -ne 0 ]; then
        error_log "Error al deserializar los correos del grupo $group"
        echo ""
        return 1
    fi
    log "INFO" "Correos obtenidos para el grupo $group: $result"
    echo "$result"
}

# Obtener el correo adicional de la extensi�n
get_extension_email() {
    extension=$1
    extension_emails_json=$($MYSQL -u$MYSQL_USER -p$MYSQL_PASS -D$MYSQL_DB -N -e "SELECT setting_value FROM emailmonitor_settings WHERE setting_key = 'extension_emails'" 2>>"$ERROR_LOG")
    if [ $? -ne 0 ]; then
        error_log "Error al obtener el correo adicional para la extensi�n $extension desde la base de datos"
        echo ""
        return 1
    fi
    log "DEBUG" "JSON de extension_emails obtenido: $extension_emails_json"
    # Deserializar el JSON y obtener el valor para la extensi�n
    result=$(php -r "\$extension_emails = json_decode('$extension_emails_json', true); echo \$extension_emails['$extension'] ?? '';" 2>>"$ERROR_LOG")
    if [ $? -ne 0 ]; then
        error_log "Error al deserializar el correo adicional para la extensi�n $extension"
        echo ""
        return 1
    fi
    log "INFO" "Correo adicional obtenido para la extensi�n $extension: $result"
    echo "$result"
}

# Obtener el nombre personalizado de la extensi�n
get_extension_name() {
    extension=$1
    extension_names_json=$($MYSQL -u$MYSQL_USER -p$MYSQL_PASS -D$MYSQL_DB -N -e "SELECT setting_value FROM emailmonitor_settings WHERE setting_key = 'extension_names'" 2>>"$ERROR_LOG")
    if [ $? -ne 0 ]; then
        error_log "Error al obtener el nombre personalizado para la extensi�n $extension desde la base de datos"
        echo ""
        return 1
    fi
    log "DEBUG" "JSON de extension_names obtenido: $extension_names_json"
    # Deserializar el JSON y obtener el valor para la extensi�n
    result=$(php -r "\$extension_names = json_decode('$extension_names_json', true); echo \$extension_names['$extension'] ?? '';" 2>>"$ERROR_LOG")
    if [ $? -ne 0 ]; then
        error_log "Error al deserializar el nombre personalizado para la extensi�n $extension"
        echo ""
        return 1
    fi
    log "INFO" "Nombre personalizado obtenido para la extensi�n $extension: $result"
    echo "$result"
}

# Obtener el intervalo de notificaci�n para la extensi�n (en minutos, convertido a segundos)
get_notification_interval() {
    extension=$1
    notification_intervals_json=$($MYSQL -u$MYSQL_USER -p$MYSQL_PASS -D$MYSQL_DB -N -e "SELECT setting_value FROM emailmonitor_settings WHERE setting_key = 'notification_intervals'" 2>>"$ERROR_LOG")
    if [ $? -ne 0 ]; then
        error_log "Error al obtener el intervalo de notificaci�n para la extensi�n $extension desde la base de datos"
        echo "60"  # Valor predeterminado: 1 minuto (60 segundos)
        return 1
    fi
    # Deserializar el JSON y obtener el valor para la extensi�n
    result=$(php -r "\$notification_intervals = json_decode('$notification_intervals_json', true); echo \$notification_intervals['$extension'] ?? '1';" 2>>"$ERROR_LOG")
    if [ $? -ne 0 ]; then
        error_log "Error al deserializar el intervalo de notificaci�n para la extensi�n $extension"
        echo "60"
        return 1
    fi
    # Convertir minutos a segundos
    seconds=$((result * 60))
    log "INFO" "Intervalo de notificaci�n para la extensi�n $extension: $result minutos ($seconds segundos)"
    echo "$seconds"
}

# Verificar si las notificaciones est�n deshabilitadas para la extensi�n
is_notification_disabled() {
    extension=$1
    disable_notifications_json=$($MYSQL -u$MYSQL_USER -p$MYSQL_PASS -D$MYSQL_DB -N -e "SELECT setting_value FROM emailmonitor_settings WHERE setting_key = 'disable_notifications'" 2>>"$ERROR_LOG")
    if [ $? -ne 0 ]; then
        error_log "Error al verificar si las notificaciones est�n deshabilitadas para la extensi�n $extension"
        echo "0"  # Por defecto, no deshabilitado
        return 1
    fi
    # Deserializar el JSON y verificar si la extensi�n tiene notificaciones deshabilitadas
    result=$(php -r "\$disable_notifications = json_decode('$disable_notifications_json', true); echo \$disable_notifications['$extension'] ?? '0';" 2>>"$ERROR_LOG")
    if [ $? -ne 0 ]; then
        error_log "Error al deserializar la configuraci�n de deshabilitar notificaciones para la extensi�n $extension"
        echo "0"
        return 1
    fi
    log "INFO" "Notificaciones deshabilitadas para la extensi�n $extension: $result"
    echo "$result"
}

# Obtener el l�mite de mensajes diarios para la extensi�n
get_daily_message_limit() {
    extension=$1
    daily_limits_json=$($MYSQL -u$MYSQL_USER -p$MYSQL_PASS -D$MYSQL_DB -N -e "SELECT setting_value FROM emailmonitor_settings WHERE setting_key = 'daily_message_limits'" 2>>"$ERROR_LOG")
    if [ $? -ne 0 ]; then
        error_log "Error al obtener el l�mite de mensajes diarios para la extensi�n $extension desde la base de datos"
        echo "10"  # Por defecto, m�nimo 10
        return 1
    fi
    # Deserializar el JSON y obtener el valor para la extensi�n
    result=$(php -r "\$daily_limits = json_decode('$daily_limits_json', true); echo \$daily_limits['$extension'] ?? '10';" 2>>"$ERROR_LOG")
    if [ $? -ne 0 ]; then
        error_log "Error al deserializar el l�mite de mensajes diarios para la extensi�n $extension"
        echo "10"
        return 1
    fi
    log "INFO" "L�mite de mensajes diarios para la extensi�n $extension: $result"
    echo "$result"
}

# Obtener y actualizar el conteo de mensajes diarios por extensi�n
get_message_count() {
    extension=$1
    current_date=$(date +%Y-%m-%d)
    count=$(grep "^$current_date $extension " "$MESSAGE_COUNT_FILE" | awk '{print $3}' || echo "0")
    echo "$count"
}

update_message_count() {
    extension=$1
    current_date=$(date +%Y-%m-%d)
    count=$(get_message_count "$extension")
    new_count=$((count + 1))
    grep -v "^$current_date $extension " "$MESSAGE_COUNT_FILE" > /tmp/message_count_tmp.txt
    if [ $? -ne 0 ]; then
        error_log "Error al usar grep en $MESSAGE_COUNT_FILE para extensi�n $extension"
        return 1
    fi
    echo "$current_date $extension $new_count" >> /tmp/message_count_tmp.txt
    mv /tmp/message_count_tmp.txt "$MESSAGE_COUNT_FILE" 2>>"$ERROR_LOG"
    if [ $? -ne 0 ]; then
        error_log "Error al mover /tmp/message_count_tmp.txt a $MESSAGE_COUNT_FILE para extensi�n $extension"
        return 1
    fi
    echo "$new_count"
}

# Obtener la �ltima vez que se envi� una notificaci�n para la extensi�n
get_last_notification_time() {
    extension=$1
    last_time=$(grep "^$extension " "$STATE_FILE" | awk '{print $3}' || echo "0")
    echo "$last_time"
}

# Obtener el tiempo en que la extensi�n entr� en estado "Lagged"
get_lagged_start_time() {
    extension=$1
    lagged_start=$(grep "^$extension " "$STATE_FILE" | awk '{print $4}' || echo "0")
    echo "$lagged_start"
}

# Actualizar el estado de la extensi�n, incluyendo el tiempo de inicio de "Lagged" si aplica
update_extension_state() {
    extension=$1
    new_status="$2"
    lagged_start="$3"
    current_time=$(date +%s)
    grep -v "^$extension " "$STATE_FILE" > /tmp/state_tmp.txt
    if [ $? -ne 0 ]; then
        error_log "Error al usar grep en $STATE_FILE para extensi�n $extension"
        return 1
    fi
    chown asterisk:asterisk /tmp/state_tmp.txt 2>>"$ERROR_LOG"
    if [ -z "$lagged_start" ] || [ "$lagged_start" = "0" ]; then
        lagged_start="0"
    fi
    echo "$extension $new_status $current_time $lagged_start" >> /tmp/state_tmp.txt
    mv /tmp/state_tmp.txt "$STATE_FILE" 2>>"$ERROR_LOG"
    if [ $? -ne 0 ]; then
        error_log "Error al mover /tmp/state_tmp.txt a $STATE_FILE para extensi�n $extension"
        return 1
    fi
    chown asterisk:asterisk "$STATE_FILE" 2>>"$ERROR_LOG"
}

# Check if an extension belongs to a group (supports ranges like 4101-4125)
extension_in_group() {
    extension=$1
    group_extensions=$2
    IFS=',' read -r -a ext_list <<< "$group_extensions"
    for range in "${ext_list[@]}"; do
        if [[ "$range" =~ ^([0-9]+)-([0-9]+)$ ]]; then
            start=${BASH_REMATCH[1]}
            end=${BASH_REMATCH[2]}
            if [ "$extension" -ge "$start" ] && [ "$extension" -le "$end" ]; then
                return 0
            fi
        elif [ "$extension" = "$range" ]; then
            return 0
        fi
    done
    return 1
}

SMTP_FROM_NAME="Tu servicio de telefonia AJTEL"
SMTP_FROM_EMAIL="soporte@ajtel.net"
SMTP_FROM=$(encode_from "$SMTP_FROM_NAME" "$SMTP_FROM_EMAIL")

log "INFO" "Script iniciado: Monitor de conexi�n de extensiones para PBX AJTEL."

[ ! -f "$STATE_FILE" ] && touch "$STATE_FILE"
[ ! -f "$MESSAGE_COUNT_FILE" ] && touch "$MESSAGE_COUNT_FILE"
[ ! -f "$LOG_FILE" ] && touch "$LOG_FILE"
[ ! -f "$ERROR_LOG" ] && touch "$ERROR_LOG"

# Ensure asterisk owns the files
chown asterisk:asterisk "$STATE_FILE" "$MESSAGE_COUNT_FILE" "$LOG_FILE" "$ERROR_LOG" 2>/dev/null
chmod 644 "$STATE_FILE" "$MESSAGE_COUNT_FILE" "$LOG_FILE" "$ERROR_LOG" 2>/dev/null

while true; do
    log "INFO" "Iniciando ciclo de monitoreo."
    OUTPUT=$($ASTERISK -rx 'sip show peers' 2>>"$ERROR_LOG")
    if [ $? -ne 0 ]; then
        error_log "Error al ejecutar 'sip show peers'"
        sleep 60
        continue
    fi
    log "DEBUG" "Salida completa de 'sip show peers': $OUTPUT"

    EXTENSIONS=$(echo "$OUTPUT" | grep -E '^[0-9]+/' || true)
    if [ -z "$EXTENSIONS" ]; then
        log "INFO" "No se encontraron extensiones SIP en la salida de 'sip show peers'."
        sleep 60
        continue
    fi
    log "INFO" "Extensiones encontradas: $EXTENSIONS"

    echo "$EXTENSIONS" | while read -r line; do
        log "DEBUG" "Procesando l�nea: $line"
        extension=$(echo "$line" | awk '{print $1}' | cut -d'/' -f1)
        ip=$(echo "$line" | awk '{print $2}')
        status=$(echo "$line" | awk '{for(i=1;i<=NF;i++) if($i ~ /^(OK|UNREACHABLE|UNKNOWN|LAGGED)$/) {print $i; exit}}')
        if [ -z "$status" ]; then
            status="UNKNOWN"
        fi
        prev_status=$(grep "^$extension " "$STATE_FILE" | awk '{print $2}' || echo "UNKNOWN")
        lagged_start=$(get_lagged_start_time "$extension")
        current_time=$(date +%s)

        log "INFO" "Tel�fono $extension: IP=$ip, Estado actual=$status, Estado anterior=$prev_status, Lagged Start Time=$lagged_start"

        # Verificar si las notificaciones est�n deshabilitadas para la extensi�n
        disabled=$(is_notification_disabled "$extension")
        if [ "$disabled" = "1" ]; then
            log "INFO" "Notificaciones deshabilitadas para la extensi�n $extension, ignorando."
            update_extension_state "$extension" "$status" "$lagged_start"
            continue
        fi

        # Manejo especial para el estado "LAGGED"
        if [ "$status" = "LAGGED" ]; then
            if [ "$lagged_start" = "0" ]; then
                # Primera vez que se detecta "LAGGED", registrar el tiempo de inicio
                lagged_start="$current_time"
                log "INFO" "Extensi�n $extension entr� en estado Lagged. Inicio: $lagged_start"
            else
                # Calcular cu�nto tiempo ha estado en "LAGGED"
                time_in_lagged=$((current_time - lagged_start))
                if [ "$time_in_lagged" -ge "$LAGGED_WAIT_TIME" ]; then
                    # Ha pasado el tiempo de espera, pero sigue en "LAGGED", no considerarlo como desconectado
                    log "INFO" "Extensi�n $extension sigue en estado Lagged despu�s de $time_in_lagged segundos. No se considera desconectado."
                    update_extension_state "$extension" "$status" "$lagged_start"
                    continue
                else
                    log "INFO" "Extensi�n $extension en estado Lagged. Tiempo transcurrido: $time_in_lagged segundos. Esperando $LAGGED_WAIT_TIME segundos."
                    update_extension_state "$extension" "$status" "$lagged_start"
                    continue
                fi
            fi
        else
            # Si el estado ya no es "LAGGED", reiniciar el tiempo de inicio de "LAGGED"
            lagged_start="0"
        fi

        if [ "$status" != "$prev_status" ]; then
            log "INFO" "Estado cambiado para tel�fono $extension."
            user_info=$(get_user_info "$extension")
            email=$(echo "$user_info" | cut -d'|' -f1)
            original_name=$(echo "$user_info" | cut -d'|' -f2)
            log "INFO" "Correo del usuario para la extensi�n $extension: $email"
            log "INFO" "Nombre original para la extensi�n $extension: $original_name"
            # Obtener el nombre personalizado, si existe, o usar el nombre original
            custom_name=$(get_extension_name "$extension")
            if [ -z "$custom_name" ]; then
                log "INFO" "No se encontr� nombre personalizado para la extensi�n $extension, usando nombre original: $original_name"
                name="$original_name"
            else
                log "INFO" "Usando nombre personalizado para la extensi�n $extension: $custom_name"
                name="$custom_name"
            fi

            # Obtener el intervalo de notificaci�n y la �ltima vez que se envi� una notificaci�n
            interval=$(get_notification_interval "$extension")
            last_notification=$(get_last_notification_time "$extension")
            time_diff=$((current_time - last_notification))

            if [ "$time_diff" -ge "$interval" ] || [ "$last_notification" = "0" ]; then
                # Verificar el l�mite de mensajes diarios por extensi�n
                daily_limit=$(get_daily_message_limit "$extension")
                message_count=$(get_message_count "$extension")
                if [ "$daily_limit" -ne 0 ] && [ "$message_count" -ge "$daily_limit" ]; then
                    log "INFO" "L�mite de mensajes diarios alcanzado para la extensi�n $extension ($message_count/$daily_limit), omitiendo notificaci�n."
                    update_extension_state "$extension" "$status" "$lagged_start"
                    continue
                fi

                # Obtener correos adicionales del m�dulo
                extension_email=$(get_extension_email "$extension")
                group_emails=""
                # Fetch group names from the database
                group_names_json=$($MYSQL -u$MYSQL_USER -p$MYSQL_PASS -D$MYSQL_DB -N -e "SELECT setting_value FROM emailmonitor_settings WHERE setting_key = 'group_names'" 2>>"$ERROR_LOG")
                group_names=$(php -r "\$group_names = json_decode('$group_names_json', true); echo implode(',', \$group_names);" 2>>"$ERROR_LOG")
                IFS=',' read -r -a group_list <<< "$group_names"
                for group in "${group_list[@]}"; do
                    group_id="group$(( ${index} + 1 ))"
                    group_extensions=$($MYSQL -u$MYSQL_USER -p$MYSQL_PASS -D$MYSQL_DB -N -e "SELECT setting_value FROM emailmonitor_settings WHERE setting_key = 'group_extensions'" 2>>"$ERROR_LOG")
                    group_extensions=$(php -r "\$group_extensions = json_decode('$group_extensions', true); echo \$group_extensions['group$(( ${index} + 1 ))'] ?? '';" 2>>"$ERROR_LOG")
                    if extension_in_group "$extension" "$group_extensions"; then
                        group_email=$(get_group_emails "group$(( ${index} + 1 ))")
                        if [ -n "$group_email" ]; then
                            group_emails="$group_emails,$group_email"
                        else
                            log "INFO" "No se encontraron correos para el grupo $group"
                        fi
                    fi
                    ((index++))
                done
                group_emails=${group_emails#,}  # Remove leading comma
                all_emails="$email"
                if [ -n "$extension_email" ]; then
                    all_emails="$all_emails,$extension_email"
                fi
                if [ -n "$group_emails" ]; then
                    all_emails="$all_emails,$group_emails"
                fi
                all_emails=${all_emails#,}  # Remove leading comma
                log "INFO" "Lista de correos combinada para enviar: $all_emails"
                if [ -n "$all_emails" ]; then
                    if [ "$status" = "UNREACHABLE" ] || [ "$status" = "UNKNOWN" ] || [ "$ip" = "(Unspecified)" ]; then
                        subject=$(encode_subject "Telefono Numero $extension Desconectado")
                        body="<!DOCTYPE html>
<html lang=\"es\">
<head>
    <meta charset=\"UTF-8\">
    <title>TELEFONO NUMERO $extension DESCONECTADO</title>
</head>
<body style=\"font-family: Arial, sans-serif; color: #333;\">
    <p>Estimado/a $name,</p>
    <p>Hemos detectado que el tel&eacute;fono n&uacute;mero $extension no est&aacute; conectado a la red. Le recomendamos verificar su conexi&oacute;n para evitar interrupciones en la recepci&oacute;n de llamadas.</p>
    <p>Atentamente,<br>Tu servicio de telefon&iacute;a AJTEL</p>
    <p>Contacto: <a href=\"mailto:soporte@ajtel.net\">soporte@ajtel.net</a> | Tel: <a href=tel:+525585265050>+52 (55) 8526-5050</a> o <a href=tel*511>*511</a> desde tu l&iacute;nea</p>
</body>
</html>"
                        message="From: $SMTP_FROM\nTo: $all_emails\nSubject: $subject\nContent-Type: text/html; charset=UTF-8\n\n$body"
                        log "INFO" "Enviando correo a $all_emails: Tel�fono N�mero $extension Desconectado"
                        sendmail_output=$(echo -e "$message" | $SENDMAIL -t 2>&1)
                        if [ $? -eq 0 ]; then
                            log "INFO" "Correo enviado exitosamente a $all_emails"
                            update_message_count "$extension"
                            update_extension_state "$extension" "$status" "$lagged_start"
                        else
                            error_log "Error al enviar correo a $all_emails: $sendmail_output"
                            update_extension_state "$extension" "$status" "$lagged_start"
                        fi
                    elif [ "$status" = "OK" ]; then
                        subject=$(encode_subject "Telefono Numero $extension Reconectado")
                        body="<!DOCTYPE html>
<html lang=\"es\">
<head>
    <meta charset=\"UTF-8\">
    <title>TELEFONO NUMERO $extension RECONECTADO</title>
</head>
<body style=\"font-family: Arial, sans-serif; color: #333;\">
    <p>Estimado/a $name,</p>
    <p>Nos complace informarle que el tel&eacute;fono n&uacute;mero $extension se ha reconectado exitosamente a la red. Ahora puede realizar y recibir llamadas con normalidad.</p>
    <p>Atentamente,<br>Tu servicio de telefon&iacute;a AJTEL</p>
    <p>Contacto: <a href=\"mailto:soporte@ajtel.net\">soporte@ajtel.net</a> | Tel: <a href=tel:+525585265050>+52 (55) 8526-5050</a> o <a href=tel*511>*511</a> desde tu l&iacute;nea</p>
</body>
</html>"
                        message="From: $SMTP_FROM\nTo: $all_emails\nSubject: $subject\nContent-Type: text/html; charset=UTF-8\nContent-Transfer-Encoding: 8bit\n\n$body"
                        log "INFO" "Enviando correo a $all_emails: Tel�fono N�mero $extension Reconectado"
                        sendmail_output=$(echo -e "$message" | $SENDMAIL -t 2>&1)
                        if [ $? -eq 0 ]; then
                            log "INFO" "Correo enviado exitosamente a $all_emails"
                            update_message_count "$extension"
                            update_extension_state "$extension" "$status" "$lagged_start"
                        else
                            error_log "Error al enviar correo a $all_emails: $sendmail_output"
                            update_extension_state "$extension" "$status" "$lagged_start"
                        fi
                    fi
                else
                    error_log "No se pudo enviar correo para el tel�fono $extension: emails no encontrados"
                    update_extension_state "$extension" "$status" "$lagged_start"
                fi
            else
                log "INFO" "Notificaci�n para la extensi�n $extension omitida: tiempo transcurrido ($time_diff segundos) menor que el intervalo ($interval segundos)"
                update_extension_state "$extension" "$status" "$lagged_start"
            fi
        else
            update_extension_state "$extension" "$status" "$lagged_start"
        fi
    done
    log "INFO" "Ciclo de monitoreo completado, esperando 60 segundos."
    sleep 60
done