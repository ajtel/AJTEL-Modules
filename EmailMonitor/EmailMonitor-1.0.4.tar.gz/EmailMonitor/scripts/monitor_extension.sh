#!/bin/bash
# ****** MONITOR DE CONEXION DE EXTENSIONES PARA PBX AJTEL *******
# Copyright (C) 1995-2025  AJTEL Comunicaciones    <info@ajtel.net>
# Copyright (C) 1995-2025  Andre Vivar Balderrama Bustamante <andrevivar@ajtel.net>
# Desarrollado por AJTEL Comunicaciones y Andre Vivar Balderrama Bustamante

# Establecer codificaci�n UTF-8 para el script
export LC_ALL=es_MX.UTF-8
export LANG=es_MX.UTF-8

STATE_FILE="/tmp/extension_status.txt"
MESSAGE_COUNT_FILE="/tmp/extension_message_count.txt"
MYSQL_DB="asterisk"
LOG_FILE="/var/log/monitor_extension.log"
ERROR_LOG="/var/log/monitor_extension_error.log"
ASTERISK="/usr/sbin/asterisk"
MYSQL="/usr/bin/mysql"
SENDMAIL="/usr/sbin/sendmail"

# Verificar que el locale sea UTF-8
if ! locale | grep -q "UTF-8"; then
    echo "Error: System locale does not support UTF-8. Please set LC_ALL=es_MX.UTF-8." >> "$ERROR_LOG"
    exit 1
fi

# Leer las credenciales de MySQL desde la configuraci�n de FreePBX
FREEPBX_CONF="/etc/freepbx.conf"
if [ ! -f "$FREEPBX_CONF" ]; then
    echo "Error: freepbx.conf not found at $FREEPBX_CONF" >> "$ERROR_LOG"
    exit 1
fi

MYSQL_USER=$(grep '^AMPDBUSER' "$FREEPBX_CONF" | cut -d'=' -f2 | tr -d ' ')
MYSQL_PASS=$(grep '^AMPDBPASS' "$FREEPBX_CONF" | cut -d'=' -f2 | tr -d ' ')

if [ -z "$MYSQL_USER" ] || [ -z "$MYSQL_PASS" ]; then
    echo "Error: Could not read MySQL credentials from $FREEPBX_CONF" >> "$ERROR_LOG"
    exit 1
fi

log() {
    # Asegurar que el mensaje se escriba con codificaci�n UTF-8
    printf "%s: %s\n" "$(date '+%Y-%m-%d %H:%M:%S')" "$(echo -e "$1" | iconv -f UTF-8 -t UTF-8)" >> "$LOG_FILE"
}

error_log() {
    printf "%s: %s\n" "$(date '+%Y-%m-%d %H:%M:%S')" "$(echo -e "$1" | iconv -f UTF-8 -t UTF-8)" >> "$ERROR_LOG"
}

encode_subject() {
    subject="$1"
    echo "=?UTF-8?B?$(echo -n "$subject" | base64)?="
}

encode_from() {
    name="$1"
    email="$2"
    echo "=?UTF-8?B?$(echo -n "$name" | base64)?= <$email>"
}

get_user_info() {
    extension=$1
    log "Obteniendo informaci�n para la extensi�n $extension"
    result=$($MYSQL -u$MYSQL_USER -p$MYSQL_PASS -D$MYSQL_DB -N -e "SELECT email, displayname, fname, lname FROM userman_users WHERE default_extension = '$extension'" 2>>"$ERROR_LOG")
    if [ $? -ne 0 ]; then
        error_log "Error al conectar a la base de datos para la extensi�n $extension"
        echo ""
        return 1
    fi
    email=$(echo "$result" | awk '{print $1}')
    displayname=$(echo "$result" | awk '{print $2}')
    fname=$(echo "$result" | awk '{print $3}')
    lname=$(echo "$result" | awk '{print $4}')
    
    log "Resultado de la consulta: extensi�n=$extension, email=$email, displayname=$displayname, fname=$fname, lname=$lname"
    
    if [ -n "$email" ] && [ "$email" != "NULL" ]; then
        if [ -n "$displayname" ] && [ "$displayname" != "NULL" ]; then
            name="$displayname"
        elif [ -n "$fname" ] && [ "$fname" != "NULL" ]; then
            name="$fname $lname"
        else
            name="Usuario"
        fi
        log "Informaci�n obtenida: extensi�n=$extension, email=$email, name=$name"
        echo "$email|$name"
    else
        error_log "Email no v�lido para la extensi�n $extension: $email"
        echo ""
    fi
}

# Obtener emails de grupo y por extensi�n desde la base de datos
get_group_emails() {
    group=$1
    group_emails_json=$($MYSQL -u$MYSQL_USER -p$MYSQL_PASS -D$MYSQL_DB -N -e "SELECT setting_value FROM emailmonitor_settings WHERE setting_key = 'group_emails'" 2>>"$ERROR_LOG")
    if [ $? -ne 0 ]; then
        error_log "Error al obtener los correos del grupo $group desde la base de datos"
        echo ""
        return 1
    fi
    log "JSON de group_emails obtenido: $group_emails_json"
    # Deserializar el JSON y obtener el valor para el grupo
    result=$(php -r "\$group_emails = json_decode('$group_emails_json', true); echo \$group_emails['$group'] ?? '';" 2>>"$ERROR_LOG")
    if [ $? -ne 0 ]; then
        error_log "Error al deserializar los correos del grupo $group"
        echo ""
        return 1
    fi
    log "Correos obtenidos para el grupo $group: $result"
    echo "$result"
}

get_extension_email() {
    extension=$1
    extension_emails_json=$($MYSQL -u$MYSQL_USER -p$MYSQL_PASS -D$MYSQL_DB -N -e "SELECT setting_value FROM emailmonitor_settings WHERE setting_key = 'extension_emails'" 2>>"$ERROR_LOG")
    if [ $? -ne 0 ]; then
        error_log "Error al obtener el correo adicional para la extensi�n $extension desde la base de datos"
        echo ""
        return 1
    fi
    log "JSON de extension_emails obtenido: $extension_emails_json"
    # Deserializar el JSON y obtener el valor para la extensi�n
    result=$(php -r "\$extension_emails = json_decode('$extension_emails_json', true); echo \$extension_emails['$extension'] ?? '';" 2>>"$ERROR_LOG")
    if [ $? -ne 0 ]; then
        error_log "Error al deserializar el correo adicional para la extensi�n $extension"
        echo ""
        return 1
    fi
    log "Correo adicional obtenido para la extensi�n $extension: $result"
    echo "$result"
}

# Obtener el nombre personalizado de la extensi�n
get_extension_name() {
    extension=$1
    extension_names_json=$($MYSQL -u$MYSQL_USER -p$MYSQL_PASS -D$MYSQL_DB -N -e "SELECT setting_value FROM emailmonitor_settings WHERE setting_key = 'extension_names'" 2>>"$ERROR_LOG")
    if [ $? -ne 0 ]; then
        error_log "Error al obtener el nombre personalizado para la extensi�n $extension desde la base de datos"
        echo ""
        return 1
    fi
    log "JSON de extension_names obtenido: $extension_names_json"
    # Deserializar el JSON y obtener el valor para la extensi�n
    result=$(php -r "\$extension_names = json_decode('$extension_names_json', true); echo \$extension_names['$extension'] ?? '';" 2>>"$ERROR_LOG")
    if [ $? -ne 0 ]; then
        error_log "Error al deserializar el nombre personalizado para la extensi�n $extension"
        echo ""
        return 1
    fi
    log "Nombre personalizado obtenido para la extensi�n $extension: $result"
    echo "$result"
}

# Obtener el intervalo de notificaci�n para la extensi�n (en minutos, convertido a segundos)
get_notification_interval() {
    extension=$1
    notification_intervals_json=$($MYSQL -u$MYSQL_USER -p$MYSQL_PASS -D$MYSQL_DB -N -e "SELECT setting_value FROM emailmonitor_settings WHERE setting_key = 'notification_intervals'" 2>>"$ERROR_LOG")
    if [ $? -ne 0 ]; then
        error_log "Error al obtener el intervalo de notificaci�n para la extensi�n $extension desde la base de datos"
        echo "60"  # Valor predeterminado: 1 minuto (60 segundos)
        return 1
    fi
    # Deserializar el JSON y obtener el valor para la extensi�n
    result=$(php -r "\$notification_intervals = json_decode('$notification_intervals_json', true); echo \$notification_intervals['$extension'] ?? '1';" 2>>"$ERROR_LOG")
    if [ $? -ne 0 ]; then
        error_log "Error al deserializar el intervalo de notificaci�n para la extensi�n $extension"
        echo "60"
        return 1
    fi
    # Convertir minutos a segundos
    seconds=$((result * 60))
    log "Intervalo de notificaci�n para la extensi�n $extension: $result minutos ($seconds segundos)"
    echo "$seconds"
}

# Verificar si las notificaciones est�n deshabilitadas para la extensi�n
is_notification_disabled() {
    extension=$1
    disable_notifications_json=$($MYSQL -u$MYSQL_USER -p$MYSQL_PASS -D$MYSQL_DB -N -e "SELECT setting_value FROM emailmonitor_settings WHERE setting_key = 'disable_notifications'" 2>>"$ERROR_LOG")
    if [ $? -ne 0 ]; then
        error_log "Error al verificar si las notificaciones est�n deshabilitadas para la extensi�n $extension"
        echo "0"  # Por defecto, no deshabilitado
        return 1
    fi
    # Deserializar el JSON y verificar si la extensi�n tiene notificaciones deshabilitadas
    result=$(php -r "\$disable_notifications = json_decode('$disable_notifications_json', true); echo \$disable_notifications['$extension'] ?? '0';" 2>>"$ERROR_LOG")
    if [ $? -ne 0 ]; then
        error_log "Error al deserializar la configuraci�n de deshabilitar notificaciones para la extensi�n $extension"
        echo "0"
        return 1
    fi
    log "Notificaciones deshabilitadas para la extensi�n $extension: $result"
    echo "$result"
}

# Obtener el l�mite de mensajes diarios para la extensi�n
get_daily_message_limit() {
    extension=$1
    daily_limits_json=$($MYSQL -u$MYSQL_USER -p$MYSQL_PASS -D$MYSQL_DB -N -e "SELECT setting_value FROM emailmonitor_settings WHERE setting_key = 'daily_message_limits'" 2>>"$ERROR_LOG")
    if [ $? -ne 0 ]; then
        error_log "Error al obtener el l�mite de mensajes diarios para la extensi�n $extension desde la base de datos"
        echo "0"  # Por defecto, sin l�mite
        return 1
    fi
    # Deserializar el JSON y obtener el valor para la extensi�n
    result=$(php -r "\$daily_limits = json_decode('$daily_limits_json', true); echo \$daily_limits['$extension'] ?? '0';" 2>>"$ERROR_LOG")
    if [ $? -ne 0 ]; then
        error_log "Error al deserializar el l�mite de mensajes diarios para la extensi�n $extension"
        echo "0"
        return 1
    fi
    log "L�mite de mensajes diarios para la extensi�n $extension: $result"
    echo "$result"
}

# Obtener y actualizar el conteo de mensajes diarios por extensi�n
get_message_count() {
    extension=$1
    current_date=$(date +%Y-%m-%d)
    count=$(grep "^$current_date $extension " "$MESSAGE_COUNT_FILE" | awk '{print $3}' || echo "0")
    echo "$count"
}

update_message_count() {
    extension=$1
    current_date=$(date +%Y-%m-%d)
    count=$(get_message_count "$extension")
    new_count=$((count + 1))
    grep -v "^$current_date $extension " "$MESSAGE_COUNT_FILE" > /tmp/message_count_tmp.txt
    echo "$current_date $extension $new_count" >> /tmp/message_count_tmp.txt
    mv /tmp/message_count_tmp.txt "$MESSAGE_COUNT_FILE" 2>>"$ERROR_LOG"
    echo "$new_count"
}

# Obtener la �ltima vez que se envi� una notificaci�n para la extensi�n
get_last_notification_time() {
    extension=$1
    last_time=$(grep "^$extension " "$STATE_FILE" | awk '{print $3}' || echo "0")
    echo "$last_time"
}

# Actualizar la �ltima vez que se envi� una notificaci�n para la extensi�n
update_last_notification_time() {
    extension=$1
    current_time=$(date +%s)
    grep -v "^$extension " "$STATE_FILE" > /tmp/state_tmp.txt
    awk -v ext="$extension" -v status="$prev_status" -v time="$current_time" '{print $0} END {print ext " " status " " time}' /tmp/state_tmp.txt > "$STATE_FILE"
}

SMTP_FROM_NAME="Tu servicio de telefonia AJTEL"
SMTP_FROM_EMAIL="soporte@ajtel.net"
SMTP_FROM=$(encode_from "$SMTP_FROM_NAME" "$SMTP_FROM_EMAIL")

log "Script iniciado: Monitor de conexi�n de extensiones para PBX AJTEL."

[ ! -f "$STATE_FILE" ] && touch "$STATE_FILE"
[ ! -f "$MESSAGE_COUNT_FILE" ] && touch "$MESSAGE_COUNT_FILE"
[ ! -f "$LOG_FILE" ] && touch "$LOG_FILE"
[ ! -f "$ERROR_LOG" ] && touch "$ERROR_LOG"

while true; do
    log "Iniciando ciclo de monitoreo."
    OUTPUT=$($ASTERISK -rx 'sip show peers' 2>>"$ERROR_LOG")
    if [ $? -ne 0 ]; then
        error_log "Error al ejecutar 'sip show peers'"
        sleep 60
        continue
    fi

    EXTENSIONS=$(echo "$OUTPUT" | grep -E '^[0-9]+/' || true)
    if [ -z "$EXTENSIONS" ]; then
        log "No se encontraron extensiones SIP en la salida de 'sip show peers'."
        sleep 60
        continue
    fi

    echo "$EXTENSIONS" | while read -r line; do
        log "Procesando l�nea: $line"
        extension=$(echo "$line" | awk '{print $1}' | cut -d'/' -f1)
        ip=$(echo "$line" | awk '{print $2}')
        status=$(echo "$line" | awk '{for(i=1;i<=NF;i++) if($i ~ /^(OK|UNREACHABLE|UNKNOWN|LAGGED)$/) {print $i; exit}}')
        if [ -z "$status" ]; then
            status="UNKNOWN"
        fi
        if [ "$status" = "LAGGED" ]; then
            status="UNREACHABLE"
        fi
        prev_status=$(grep "^$extension " "$STATE_FILE" | awk '{print $2}' || echo "UNKNOWN")
        log "Tel�fono $extension: IP=$ip, Estado actual=$status, Estado anterior=$prev_status"

        # Verificar si las notificaciones est�n deshabilitadas para la extensi�n
        disabled=$(is_notification_disabled "$extension")
        if [ "$disabled" = "1" ]; then
            log "Notificaciones deshabilitadas para la extensi�n $extension, ignorando."
            continue
        fi

        if [ "$status" != "$prev_status" ]; then
            log "Estado cambiado para tel�fono $extension."
            user_info=$(get_user_info "$extension")
            email=$(echo "$user_info" | cut -d'|' -f1)
            original_name=$(echo "$user_info" | cut -d'|' -f2)
            log "Correo del usuario para la extensi�n $extension: $email"
            log "Nombre original para la extensi�n $extension: $original_name"
            # Obtener el nombre personalizado, si existe, o usar el nombre original
            custom_name=$(get_extension_name "$extension")
            if [ -z "$custom_name" ]; then
                log "No se encontr� nombre personalizado para la extensi�n $extension, usando nombre original: $original_name"
                name="$original_name"
            else
                log "Usando nombre personalizado para la extensi�n $extension: $custom_name"
                name="$custom_name"
            fi

            # Obtener el intervalo de notificaci�n y la �ltima vez que se envi� una notificaci�n
            interval=$(get_notification_interval "$extension")
            last_notification=$(get_last_notification_time "$extension")
            current_time=$(date +%s)
            time_diff=$((current_time - last_notification))

            if [ "$time_diff" -ge "$interval" ] || [ "$last_notification" = "0" ]; then
                # Verificar el l�mite de mensajes diarios por extensi�n
                daily_limit=$(get_daily_message_limit "$extension")
                message_count=$(get_message_count "$extension")
                if [ "$daily_limit" -ne 0 ] && [ "$message_count" -ge "$daily_limit" ]; then
                    log "L�mite de mensajes diarios alcanzado para la extensi�n $extension ($message_count/$daily_limit), omitiendo notificaci�n."
                    continue
                fi

                # Obtener correos adicionales del m�dulo
                extension_email=$(get_extension_email "$extension")
                group_emails=""
                for group in transito dif proteccioncivil yesenia marcela; do
                    group_email=$(get_group_emails "$group")
                    if [ -n "$group_email" ]; then
                        group_emails="$group_emails,$group_email"
                    fi
                done
                group_emails=${group_emails#,}  # Remove leading comma
                all_emails="$email"
                if [ -n "$extension_email" ]; then
                    all_emails="$all_emails,$extension_email"
                fi
                if [ -n "$group_emails" ]; then
                    all_emails="$all_emails,$group_emails"
                fi
                all_emails=${all_emails#,}  # Remove leading comma
                log "Lista de correos combinada para enviar: $all_emails"
                if [ -n "$all_emails" ]; then
                    if [ "$status" = "UNREACHABLE" ] || [ "$status" = "UNKNOWN" ] || [ "$ip" = "(Unspecified)" ]; then
                        subject=$(encode_subject "Telefono Numero $extension Desconectado")
                        body="<!DOCTYPE html>
<html lang=\"es\">
<head>
    <meta charset=\"UTF-8\">
    <title>TELEFONO NUMERO $extension DESCONECTADO</title>
</head>
<body style=\"font-family: Arial, sans-serif; color: #333;\">
    <p>Estimado/a $name,</p>
    <p>Hemos detectado que el tel&eacute;fono n&uacute;mero $extension no est&aacute; conectado a la red. Le recomendamos verificar su conexi&oacute;n para evitar interrupciones en la recepci&oacute;n de llamadas.</p>
    <p>Atentamente,<br>Tu servicio de telefon&iacute;a AJTEL</p>
    <p>Contacto: <a href=\"mailto:soporte@ajtel.net\">soporte@ajtel.net</a> | Tel: <a href=tel:+525585265050>+52 (55) 8526-5050</a> o <a href=tel*511>*511</a> desde tu l&iacute;nea</p>
</body>
</html>"
                        message="From: $SMTP_FROM\nTo: $all_emails\nSubject: $subject\nContent-Type: text/html; charset=UTF-8\n\n$body"
                        log "Enviando correo a $all_emails: Tel�fono N�mero $extension Desconectado"
                        sendmail_output=$(echo -e "$message" | $SENDMAIL -t 2>&1)
                        if [ $? -eq 0 ]; then
                            log "Correo enviado exitosamente a $all_emails"
                            update_last_notification_time "$extension"
                            update_message_count "$extension"
                        else
                            error_log "Error al enviar correo a $all_emails: $sendmail_output"
                        fi
                    elif [ "$status" = "OK" ]; then
                        subject=$(encode_subject "Telefono Numero $extension Reconectado")
                        body="<!DOCTYPE html>
<html lang=\"es\">
<head>
    <meta charset=\"UTF-8\">
    <title>TELEFONO NUMERO $extension RECONECTADO</title>
</head>
<body style=\"font-family: Arial, sans-serif; color: #333;\">
    <p>Estimado/a $name,</p>
    <p>Nos complace informarle que el tel&eacute;fono n&uacute;mero $extension se ha reconectado exitosamente a la red. Ahora puede realizar y recibir llamadas con normalidad.</p>
    <p>Atentamente,<br>Tu servicio de telefon&iacute;a AJTEL</p>
    <p>Contacto: <a href=\"mailto:soporte@ajtel.net\">soporte@ajtel.net</a> | Tel: <a href=tel:+525585265050>+52 (55) 8526-5050</a> o <a href=tel*511>*511</a> desde tu l&iacute;nea</p>
</body>
</html>"
                        message="From: $SMTP_FROM\nTo: $all_emails\nSubject: $subject\nContent-Type: text/html; charset=UTF-8\nContent-Transfer-Encoding: 8bit\n\n$body"
                        log "Enviando correo a $all_emails: Tel�fono N�mero $extension Reconectado"
                        sendmail_output=$(echo -e "$message" | $SENDMAIL -t 2>&1)
                        if [ $? -eq 0 ]; then
                            log "Correo enviado exitosamente a $all_emails"
                            update_last_notification_time "$extension"
                            update_message_count "$extension"
                        else
                            error_log "Error al enviar correo a $all_emails: $sendmail_output"
                        fi
                    fi
                else
                    error_log "No se pudo enviar correo para el tel�fono $extension: emails no encontrados"
                fi
            else
                log "Notificaci�n para la extensi�n $extension omitida: tiempo transcurrido ($time_diff segundos) menor que el intervalo ($interval segundos)"
            fi
        fi

        log "Actualizando estado para tel�fono $extension"
        grep -v "^$extension " "$STATE_FILE" > /tmp/state_tmp.txt
        current_time=$(get_last_notification_time "$extension")
        echo "$extension $status $current_time" >> /tmp/state_tmp.txt
        mv /tmp/state_tmp.txt "$STATE_FILE" 2>>"$ERROR_LOG"
        log "Estado actualizado para tel�fono $extension"
    done
    log "Ciclo de monitoreo completado, esperando 60 segundos."
    sleep 60
done