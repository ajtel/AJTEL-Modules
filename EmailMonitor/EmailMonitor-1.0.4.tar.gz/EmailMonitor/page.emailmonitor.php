<?php
// ****** INSTALADOR DE MONITOR DE CONEXION DE EXTENSIONES PARA PBX BY AJTEL *******
// Copyright (C) 1995-2025  AJTEL Comunicaciones    <info@ajtel.net>
// Copyright (C) 1995-2025  Andre Vivar Balderrama Bustamante <andrevivar@ajtel.net>
// Desarrollado por AJTEL Comunicaciones y Andre Vivar Balderrama Bustamante

// page.emailmonitor.php
if (!defined('FREEPBX_IS_AUTH')) { die('No direct script access allowed'); }

// Debug: Log to confirm this file is being accessed
file_put_contents('/var/log/asterisk/freepbx.log', date('Y-m-d H:i:s') . " - Accessing page.emailmonitor.php\n", FILE_APPEND);

// Include FreePBX bootstrap environment
require_once '/var/www/html/admin/bootstrap.php';

// Debug: Log to confirm bootstrap is loaded
file_put_contents('/var/log/asterisk/freepbx.log', date('Y-m-d H:i:s') . " - Bootstrap loaded\n", FILE_APPEND);

// Instantiate the Emailmonitor class (lowercase)
try {
    $emailmonitor = \FreePBX::Emailmonitor();
    file_put_contents('/var/log/asterisk/freepbx.log', date('Y-m-d H:i:s') . " - Emailmonitor class instantiated successfully\n", FILE_APPEND);
} catch (Exception $e) {
    file_put_contents('/var/log/asterisk/freepbx.log', date('Y-m-d H:i:s') . " - Failed to instantiate Emailmonitor class: " . $e->getMessage() . "\n", FILE_APPEND);
    throw $e;
}

// Handle form submissions or other actions
$emailmonitor->doConfigPageInit('emailmonitor');

// Display the page content
echo $emailmonitor->showPage();

// Add JavaScript for form submission (optional, for better UX)
?>
<script type="text/javascript">
    $(document).ready(function() {
        $('#save').click(function() {
            $('#emailmonitor_form').submit();
        });
    });
</script>